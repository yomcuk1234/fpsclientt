package com.fpsclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class MenuScreen extends Screen {
    public MenuScreen() {
        super(Text.literal("FPS Client"));
    }

    @Override
    protected void init() {
        Config c = FpsClient.CFG;
        int y = this.height / 2 - 60;
        toggle(y, "FPS göstergesi", () -> c.showFps, v -> c.showFps = v);
        toggle(y + 24, "CPS göstergesi", () -> c.showCps, v -> c.showCps = v);
        toggle(y + 48, "Koordinatlar", () -> c.showCoords, v -> c.showCoords = v);
        toggle(y + 72, "Toggle Sprint", () -> c.toggleSprint, v -> c.toggleSprint = v);
        toggle(y + 96, "Performans modu", () -> c.perfMode, v -> c.perfMode = v);
        addDrawableChild(ButtonWidget.builder(Text.literal("Kapat"), b -> close())
                .dimensions(this.width / 2 - 100, y + 126, 200, 20).build());
    }

    private void toggle(int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
            FpsClient.CFG.save();
            FpsClient.applyPerf();
        }).dimensions(this.width / 2 - 100, y, 200, 20).build());
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "AÇIK" : "KAPALI"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 85, 0xFFFFFFFF);
    }
}

package com.fpsclient;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class Config {
    public boolean showFps = true;
    public boolean showCps = true;
    public boolean showCoords = false;
    public boolean toggleSprint = false;
    public boolean perfMode = false;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("fpsclient.properties");
    }

    public void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f)) {
            Properties p = new Properties();
            p.load(r);
            showFps = Boolean.parseBoolean(p.getProperty("showFps", "true"));
            showCps = Boolean.parseBoolean(p.getProperty("showCps", "true"));
            showCoords = Boolean.parseBoolean(p.getProperty("showCoords", "false"));
            toggleSprint = Boolean.parseBoolean(p.getProperty("toggleSprint", "false"));
            perfMode = Boolean.parseBoolean(p.getProperty("perfMode", "false"));
        } catch (IOException ignored) {
        }
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("showFps", String.valueOf(showFps));
        p.setProperty("showCps", String.valueOf(showCps));
        p.setProperty("showCoords", String.valueOf(showCoords));
        p.setProperty("toggleSprint", String.valueOf(toggleSprint));
        p.setProperty("perfMode", String.valueOf(perfMode));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "FPS Client");
        } catch (IOException ignored) {
        }
    }
}

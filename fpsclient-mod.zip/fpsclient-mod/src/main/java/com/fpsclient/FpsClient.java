package com.fpsclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

public class FpsClient implements ClientModInitializer {
    public static final Config CFG = new Config();
    private static KeyBinding menuKey;
    private static final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private static boolean wasAttack = false;

    @Override
    public void onInitializeClient() {
        CFG.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("fpsclient", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.fpsclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, category));

        ClientTickEvents.END_CLIENT_TICK.register(FpsClient::onTick);
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("fpsclient", "hud"),
                FpsClient::renderHud);
    }

    private static void onTick(MinecraftClient mc) {
        // CPS takibi (sol tık)
        boolean attack = mc.options.attackKey.isPressed();
        long now = System.currentTimeMillis();
        if (attack && !wasAttack) clicks.add(now);
        wasAttack = attack;
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();

        // P ile menü
        while (menuKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new MenuScreen());
        }

        // Toggle sprint
        if (CFG.toggleSprint && mc.player != null && mc.currentScreen == null
                && mc.options.forwardKey.isPressed()
                && !mc.player.isSneaking()
                && !mc.player.horizontalCollision
                && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }

    private static void renderHud(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        int y = 6;
        if (CFG.showFps) {
            ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 6, y, 0xFFFFFFFF);
            y += 11;
        }
        if (CFG.showCps) {
            ctx.drawTextWithShadow(mc.textRenderer, "CPS: " + clicks.size(), 6, y, 0xFFFFFFFF);
            y += 11;
        }
        if (CFG.showCoords) {
            String c = "XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
            ctx.drawTextWithShadow(mc.textRenderer, c, 6, y, 0xFFFFFFFF);
        }
    }

    /** Performans modu: parçacıkları ve uzak varlık çizimini azaltır. */
    public static void applyPerf() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (CFG.perfMode) {
            mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
            mc.options.getEntityDistanceScaling().setValue(0.5);
        } else {
            mc.options.getParticles().setValue(ParticlesMode.ALL);
            mc.options.getEntityDistanceScaling().setValue(1.0);
        }
        mc.options.write();
    }
}
